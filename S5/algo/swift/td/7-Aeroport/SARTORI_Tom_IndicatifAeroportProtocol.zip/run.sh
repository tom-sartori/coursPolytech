swiftc IndicatifAeroportProtocol.swift main.swift 
./main