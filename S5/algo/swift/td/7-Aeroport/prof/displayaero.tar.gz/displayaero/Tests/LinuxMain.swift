import XCTest

import displayaeroTests

var tests = [XCTestCaseEntry]()
tests += displayaeroTests.allTests()
XCTMain(tests)