{
	"rules": {
		"indent": ["error", "tab"],
		"quotes": ["error", "double"],
		"max-len": ["error", 250],
		"curly": "error",
		"camelcase": ["error", {"properties": "never"}],
		"no-trailing-spaces": ["error", {"ignoreComments": false }],
		"no-irregular-whitespace": ["error"]
	},
	"env": {
		"browser": true,
		"node": true,
		"es6": true
	},
	"parserOptions": {
		"sourceType": "module",
		"ecmaFeatures": {
			"globalReturn": true
		}
    }
}
