ps ux | grep ps
echo ^^^^^^^^^
