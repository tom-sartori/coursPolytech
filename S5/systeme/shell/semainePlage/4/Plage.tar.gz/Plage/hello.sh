echo "Quel est votre nom ?"
read NOM
echo "Bienvenu $NOM"
